# Cat > 2025-06-07 12:20am
https://universe.roboflow.com/project-gjxnt/cat-ccike

Provided by a Roboflow user
License: CC BY 4.0

